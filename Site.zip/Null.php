<!DOCTYPE html>
<html lang="en">

<?php include '_header.php'; ?>
<!-- Topbar End -->

<!-- Navbar Start -->
<?php include '_navbar.php'; ?>
<!-- Navbar End -->

<!-- PAGE CONTENT START -->
<div class="container-xxl py-5">
    <div class="container">
        
        <!-- Conteúdo em branco -->
        <div class="row">
            <div class="col-12">
                <!-- Adicione aqui o conteúdo da nova página -->
            </div>
        </div>

    </div>
</div>
<!-- PAGE CONTENT END -->

<!-- Footer Start -->
<?php include '_footer.php'; ?>
<!-- Footer End -->

<!-- Back to Top -->
<?php include '_backtop.php'; ?>

</body>
</html>
